package com.example.ui.screens

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.data.model.WeatherCondition
import com.example.ui.components.CitySearchModal
import com.example.ui.components.DailyForecastCard
import com.example.ui.components.InteractiveHourlyChart
import com.example.ui.components.WeatherHeader
import com.example.ui.components.WeatherMetricGrid
import com.example.ui.viewmodel.WeatherViewModel
import com.google.android.gms.location.LocationServices
import kotlinx.coroutines.launch

@SuppressLint("MissingPermission")
@Composable
fun WeatherScreen(
    viewModel: WeatherViewModel = viewModel(),
    modifier: Modifier = Modifier
) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val context = LocalContext.current
    val snackbarHostState = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()

    // Location Permission launcher
    val locationPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions()
    ) { permissions ->
        val granted = permissions[Manifest.permission.ACCESS_FINE_LOCATION] == true ||
                permissions[Manifest.permission.ACCESS_COARSE_LOCATION] == true
        if (granted) {
            val fusedClient = LocationServices.getFusedLocationProviderClient(context)
            fusedClient.lastLocation.addOnSuccessListener { loc ->
                if (loc != null) {
                    viewModel.useCurrentLocation(loc.latitude, loc.longitude)
                    scope.launch {
                        snackbarHostState.showSnackbar("Detected your current location")
                    }
                } else {
                    scope.launch {
                        snackbarHostState.showSnackbar("Location unavailable; using default city")
                    }
                }
            }.addOnFailureListener {
                scope.launch {
                    snackbarHostState.showSnackbar("Unable to fetch location")
                }
            }
        } else {
            scope.launch {
                snackbarHostState.showSnackbar("Location permission denied; select city manually")
            }
        }
    }

    // Trigger notice snackbar if any
    LaunchedEffect(uiState.userNotice) {
        uiState.userNotice?.let { notice ->
            snackbarHostState.showSnackbar(notice)
            viewModel.clearNotice()
        }
    }

    // Weather condition theme colors
    val condition = uiState.currentWeather?.condition ?: WeatherCondition.CLEAR_SKY
    val isDay = uiState.currentWeather?.isDay ?: true

    val gradientTop by animateColorAsState(
        targetValue = if (isDay) condition.gradientTop else Color(0xFF0B132B),
        animationSpec = tween(600),
        label = "bg_top"
    )
    val gradientBottom by animateColorAsState(
        targetValue = if (isDay) condition.gradientBottom else Color(0xFF1C2541),
        animationSpec = tween(600),
        label = "bg_bottom"
    )

    Scaffold(
        modifier = modifier
            .fillMaxSize()
            .testTag("weather_screen"),
        snackbarHost = { SnackbarHost(snackbarHostState) },
        containerColor = Color.Transparent
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.verticalGradient(
                        listOf(gradientTop, gradientBottom)
                    )
                )
                .statusBarsPadding()
                .navigationBarsPadding()
        ) {
            if (uiState.isLoading && uiState.currentWeather == null) {
                // Initial Loading State
                Box(
                    modifier = Modifier.fillMaxSize(),
                    contentAlignment = Alignment.Center
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        CircularProgressIndicator(
                            color = Color(0xFF60A5FA),
                            strokeWidth = 3.dp
                        )
                        Text(
                            text = "Loading weather forecast...",
                            style = MaterialTheme.typography.bodyMedium,
                            color = Color.White.copy(alpha = 0.8f)
                        )
                    }
                }
            } else {
                val weather = uiState.currentWeather
                if (weather != null) {
                    LazyColumn(
                        modifier = Modifier.fillMaxSize(),
                        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 8.dp, bottom = 32.dp),
                        verticalArrangement = Arrangement.spacedBy(20.dp)
                    ) {
                        // Header with Location, Local Date/Time, Unit switcher, Actions
                        item(key = "header") {
                            WeatherHeader(
                                weather = weather,
                                unit = uiState.unit,
                                favoriteCities = uiState.favoriteCities,
                                isRefreshing = uiState.isRefreshing,
                                onOpenSearch = { viewModel.openSearch() },
                                onToggleUnit = { viewModel.toggleUnit() },
                                onToggleFavorite = { viewModel.toggleFavoriteCurrentCity() },
                                onRefresh = { viewModel.refresh() },
                                onCitySelected = { city -> viewModel.loadWeatherForCity(city) },
                                onRequestLocation = {
                                    locationPermissionLauncher.launch(
                                        arrayOf(
                                            Manifest.permission.ACCESS_FINE_LOCATION,
                                            Manifest.permission.ACCESS_COARSE_LOCATION
                                        )
                                    )
                                }
                            )
                        }

                        // Interactive Hourly Temperature & Metric Graph
                        item(key = "hourly_chart") {
                            InteractiveHourlyChart(
                                hourlyPoints = uiState.activeHourlyList,
                                selectedPoint = uiState.selectedHourlyPoint,
                                metric = uiState.graphMetric,
                                unit = uiState.unit,
                                onPointSelected = { point -> viewModel.selectHourlyPoint(point) },
                                onMetricChanged = { m -> viewModel.setGraphMetric(m) }
                            )
                        }

                        // 5-Day Forecast Card with day selection
                        item(key = "five_day_forecast") {
                            DailyForecastCard(
                                forecastDays = weather.fiveDayForecast,
                                selectedIndex = uiState.selectedDayIndex,
                                unit = uiState.unit,
                                onDaySelected = { index -> viewModel.selectDay(index) }
                            )
                        }

                        // Detailed Tracking Metrics Grid: Rain Chance, UV Index, Wind & Compass, Humidity, Solar
                        item(key = "metric_grid") {
                            WeatherMetricGrid(
                                weather = weather,
                                unit = uiState.unit
                            )
                        }
                    }
                }
            }

            // City Search Modal
            CitySearchModal(
                isOpen = uiState.isSearchOpen,
                query = uiState.searchQuery,
                results = uiState.searchResults,
                isSearching = uiState.isSearching,
                onQueryChanged = { q -> viewModel.onSearchQueryChanged(q) },
                onCitySelected = { city -> viewModel.loadWeatherForCity(city) },
                onDismiss = { viewModel.closeSearch() }
            )
        }
    }
}
