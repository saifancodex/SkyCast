package com.example.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.CityDatabase
import com.example.data.model.CityLocation
import com.example.data.model.CurrentWeatherData
import com.example.data.model.DailyForecastDay
import com.example.data.model.GraphMetricType
import com.example.data.model.HourlyDataPoint
import com.example.data.model.TemperatureUnit
import com.example.data.repository.WeatherRepository
import com.example.util.DateTimeHelper
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

data class WeatherUiState(
    val isLoading: Boolean = true,
    val isRefreshing: Boolean = false,
    val currentWeather: CurrentWeatherData? = null,
    val selectedCity: CityLocation = CityDatabase.defaultCity(),
    val unit: TemperatureUnit = TemperatureUnit.CELSIUS,
    val selectedDayIndex: Int = 0,
    val selectedHourlyPoint: HourlyDataPoint? = null,
    val graphMetric: GraphMetricType = GraphMetricType.TEMPERATURE,
    val isSearchOpen: Boolean = false,
    val searchQuery: String = "",
    val searchResults: List<CityLocation> = CityDatabase.POPULAR_CITIES,
    val isSearching: Boolean = false,
    val favoriteCities: List<CityLocation> = CityDatabase.POPULAR_CITIES.filter { it.isFavorite },
    val userNotice: String? = null
) {
    val activeHourlyList: List<HourlyDataPoint>
        get() {
            val weather = currentWeather ?: return emptyList()
            return if (selectedDayIndex == 0) {
                weather.hourlyForecast
            } else {
                val day = weather.fiveDayForecast.getOrNull(selectedDayIndex)
                day?.hourlyPoints?.ifEmpty { weather.hourlyForecast } ?: weather.hourlyForecast
            }
        }

    val activeDay: DailyForecastDay?
        get() = currentWeather?.fiveDayForecast?.getOrNull(selectedDayIndex)
}

class WeatherViewModel(
    private val repository: WeatherRepository = WeatherRepository()
) : ViewModel() {

    private val _uiState = MutableStateFlow(WeatherUiState())
    val uiState: StateFlow<WeatherUiState> = _uiState.asStateFlow()

    private var timeTickerJob: Job? = null
    private var searchJob: Job? = null

    init {
        loadWeatherForCity(_uiState.value.selectedCity)
        startTimeTicker()
    }

    private fun startTimeTicker() {
        timeTickerJob?.cancel()
        timeTickerJob = viewModelScope.launch {
            while (isActive) {
                delay(30_000) // update every 30 seconds
                val current = _uiState.value.currentWeather ?: continue
                val timeInfo = DateTimeHelper.getPlaceZonedInfo(current.location.timezone)
                _uiState.update { state ->
                    state.copy(
                        currentWeather = current.copy(
                            formattedDate = timeInfo.formattedDate,
                            formattedTime = timeInfo.formattedTime
                        )
                    )
                }
            }
        }
    }

    fun loadWeatherForCity(city: CityLocation) {
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true, selectedCity = city, selectedHourlyPoint = null, selectedDayIndex = 0) }
            val data = repository.fetchWeather(city)
            _uiState.update {
                it.copy(
                    isLoading = false,
                    isRefreshing = false,
                    currentWeather = data,
                    selectedHourlyPoint = data.hourlyForecast.firstOrNull()
                )
            }
        }
    }

    fun refresh() {
        viewModelScope.launch {
            _uiState.update { it.copy(isRefreshing = true) }
            val data = repository.fetchWeather(_uiState.value.selectedCity)
            _uiState.update {
                it.copy(
                    isRefreshing = false,
                    currentWeather = data,
                    selectedHourlyPoint = data.hourlyForecast.firstOrNull()
                )
            }
        }
    }

    fun toggleUnit() {
        _uiState.update {
            val nextUnit = if (it.unit == TemperatureUnit.CELSIUS) TemperatureUnit.FAHRENHEIT else TemperatureUnit.CELSIUS
            it.copy(unit = nextUnit)
        }
    }

    fun selectDay(index: Int) {
        _uiState.update { state ->
            val weather = state.currentWeather
            val day = weather?.fiveDayForecast?.getOrNull(index)
            val initialPoint = day?.hourlyPoints?.firstOrNull() ?: weather?.hourlyForecast?.firstOrNull()
            state.copy(
                selectedDayIndex = index,
                selectedHourlyPoint = initialPoint
            )
        }
    }

    fun selectHourlyPoint(point: HourlyDataPoint?) {
        _uiState.update { it.copy(selectedHourlyPoint = point) }
    }

    fun setGraphMetric(metric: GraphMetricType) {
        _uiState.update { it.copy(graphMetric = metric) }
    }

    fun openSearch() {
        _uiState.update { it.copy(isSearchOpen = true, searchQuery = "", searchResults = CityDatabase.POPULAR_CITIES) }
    }

    fun closeSearch() {
        _uiState.update { it.copy(isSearchOpen = false, searchQuery = "") }
    }

    fun onSearchQueryChanged(query: String) {
        _uiState.update { it.copy(searchQuery = query) }
        searchJob?.cancel()
        searchJob = viewModelScope.launch {
            if (query.isBlank()) {
                _uiState.update { it.copy(searchResults = CityDatabase.POPULAR_CITIES, isSearching = false) }
                return@launch
            }
            _uiState.update { it.copy(isSearching = true) }
            delay(250) // debounce
            val results = repository.searchCities(query)
            _uiState.update { it.copy(searchResults = results, isSearching = false) }
        }
    }

    fun toggleFavoriteCurrentCity() {
        val currentCity = _uiState.value.selectedCity
        val isNowFav = repository.toggleFavorite(currentCity)
        val updatedCity = currentCity.copy(isFavorite = isNowFav)
        val updatedWeather = _uiState.value.currentWeather?.copy(
            location = updatedCity
        )
        val favs = if (isNowFav) {
            (_uiState.value.favoriteCities + updatedCity).distinctBy { it.name + it.country }
        } else {
            _uiState.value.favoriteCities.filterNot { it.name == currentCity.name && it.country == currentCity.country }
        }
        _uiState.update {
            it.copy(
                selectedCity = updatedCity,
                currentWeather = updatedWeather,
                favoriteCities = favs,
                userNotice = if (isNowFav) "${currentCity.name} saved to favorites" else "${currentCity.name} removed from favorites"
            )
        }
    }

    fun clearNotice() {
        _uiState.update { it.copy(userNotice = null) }
    }

    fun useCurrentLocation(latitude: Double, longitude: Double) {
        val customLoc = CityLocation(
            id = "current_gps",
            name = "My Location",
            country = "Local",
            latitude = latitude,
            longitude = longitude,
            timezone = "auto",
            isFavorite = false
        )
        loadWeatherForCity(customLoc)
    }

    override fun onCleared() {
        super.onCleared()
        timeTickerJob?.cancel()
        searchJob?.cancel()
    }
}
