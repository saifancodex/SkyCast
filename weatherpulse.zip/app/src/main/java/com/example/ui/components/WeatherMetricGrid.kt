package com.example.ui.components

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Air
import androidx.compose.material.icons.filled.Brightness5
import androidx.compose.material.icons.filled.Compress
import androidx.compose.material.icons.filled.Navigation
import androidx.compose.material.icons.filled.Thermostat
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.WaterDrop
import androidx.compose.material.icons.filled.WbSunny
import androidx.compose.material.icons.outlined.WbTwilight
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.CurrentWeatherData
import com.example.data.model.TemperatureUnit
import java.util.Locale
import kotlin.math.roundToInt

@Composable
fun WeatherMetricGrid(
    weather: CurrentWeatherData,
    unit: TemperatureUnit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text(
            text = "Weather Details",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold,
            color = Color.White,
            modifier = Modifier.padding(horizontal = 4.dp)
        )

        // Row 1: Chance of Rain & UV Index Tracking
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // Chance of Rain Card
            RainChanceCard(
                precipitationProbability = weather.precipitationProbability,
                precipitationAmount = unit.convertPrecipitation(weather.precipitationMm),
                precipitationUnit = unit.precipitationUnit,
                rainSummary = weather.rainSummary,
                modifier = Modifier
                    .weight(1f)
                    .testTag("metric_rain_card")
            )

            // UV Index Tracking Card
            UvIndexCard(
                uvIndex = weather.uvIndex,
                uvLevel = weather.uvLevelDescription,
                sunAdvice = weather.uvSunAdvice,
                modifier = Modifier
                    .weight(1f)
                    .testTag("metric_uv_card")
            )
        }

        // Row 2: Wind Speed & Compass + Humidity & Comfort
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // Wind Speed & Direction Card
            WindCard(
                windSpeed = unit.convertSpeed(weather.windSpeedKmh),
                windGusts = unit.convertSpeed(weather.windGustsKmh),
                speedUnit = unit.speedUnit,
                windDirectionDeg = weather.windDirectionDeg,
                compassDirection = weather.windDirectionCompass,
                modifier = Modifier
                    .weight(1f)
                    .testTag("metric_wind_card")
            )

            // Humidity & Comfort Card
            HumidityCard(
                humidityPercent = weather.humidityPercent,
                comfortLabel = weather.humidityComfort,
                modifier = Modifier
                    .weight(1f)
                    .testTag("metric_humidity_card")
            )
        }

        // Row 3: Sunrise/Sunset Solar Arch + Pressure/Visibility
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            SunriseSunsetCard(
                sunrise = weather.sunriseTime,
                sunset = weather.sunsetTime,
                modifier = Modifier
                    .weight(1f)
                    .testTag("metric_sun_card")
            )

            AtmosphereCard(
                pressureHpa = weather.pressureHpa,
                cloudCover = weather.cloudCoverPercent,
                modifier = Modifier
                    .weight(1f)
                    .testTag("metric_atmosphere_card")
            )
        }
    }
}

@Composable
fun RainChanceCard(
    precipitationProbability: Int,
    precipitationAmount: Float,
    precipitationUnit: String,
    rainSummary: String,
    modifier: Modifier = Modifier
) {
    MetricContainer(
        title = "Chance of Rain",
        icon = Icons.Filled.WaterDrop,
        iconTint = Color(0xFF38BDF8),
        modifier = modifier
    ) {
        Column {
            Row(
                verticalAlignment = Alignment.Bottom
            ) {
                Text(
                    text = "$precipitationProbability",
                    fontSize = 32.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
                Text(
                    text = "%",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = Color(0xFF38BDF8),
                    modifier = Modifier.padding(bottom = 4.dp, start = 2.dp)
                )
            }

            Spacer(modifier = Modifier.height(4.dp))

            // Visual probability meter bar
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(6.dp)
                    .clip(CircleShape)
                    .background(Color.White.copy(alpha = 0.15f))
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth((precipitationProbability / 100f).coerceIn(0.04f, 1f))
                        .height(6.dp)
                        .clip(CircleShape)
                        .background(
                            Brush.horizontalGradient(
                                listOf(Color(0xFF0284C7), Color(0xFF38BDF8))
                            )
                        )
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = String.format(Locale.US, "Precip: %.1f %s", precipitationAmount, precipitationUnit),
                style = MaterialTheme.typography.labelSmall,
                color = Color.White.copy(alpha = 0.8f)
            )

            Text(
                text = rainSummary,
                style = MaterialTheme.typography.bodySmall,
                color = Color.White.copy(alpha = 0.65f),
                maxLines = 2
            )
        }
    }
}

@Composable
fun UvIndexCard(
    uvIndex: Float,
    uvLevel: String,
    sunAdvice: String,
    modifier: Modifier = Modifier
) {
    val uvColor = when {
        uvIndex < 3f -> Color(0xFF4ADE80) // Low - Green
        uvIndex < 6f -> Color(0xFFFBBF24) // Moderate - Yellow
        uvIndex < 8f -> Color(0xFFFB923C) // High - Orange
        uvIndex < 11f -> Color(0xFFF43F5E) // Very High - Red
        else -> Color(0xFFA855F7) // Extreme - Violet
    }

    MetricContainer(
        title = "UV Index",
        icon = Icons.Filled.Brightness5,
        iconTint = uvColor,
        modifier = modifier
    ) {
        Column {
            Row(
                verticalAlignment = Alignment.Bottom
            ) {
                Text(
                    text = String.format(Locale.US, "%.1f", uvIndex),
                    fontSize = 32.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
                Spacer(modifier = Modifier.width(6.dp))
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = uvColor.copy(alpha = 0.2f),
                    modifier = Modifier.padding(bottom = 4.dp)
                ) {
                    Text(
                        text = uvLevel,
                        color = uvColor,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(6.dp))

            // Rainbow UV Gauge
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(6.dp)
                    .clip(CircleShape)
                    .background(
                        Brush.horizontalGradient(
                            listOf(
                                Color(0xFF4ADE80),
                                Color(0xFFFBBF24),
                                Color(0xFFFB923C),
                                Color(0xFFF43F5E),
                                Color(0xFFA855F7)
                            )
                        )
                    )
            )

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = sunAdvice,
                style = MaterialTheme.typography.bodySmall,
                color = Color.White.copy(alpha = 0.65f),
                maxLines = 2
            )
        }
    }
}

@Composable
fun WindCard(
    windSpeed: Float,
    windGusts: Float,
    speedUnit: String,
    windDirectionDeg: Int,
    compassDirection: String,
    modifier: Modifier = Modifier
) {
    MetricContainer(
        title = "Wind",
        icon = Icons.Filled.Air,
        iconTint = Color(0xFF4ADE80),
        modifier = modifier
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Row(verticalAlignment = Alignment.Bottom) {
                    Text(
                        text = "${windSpeed.roundToInt()}",
                        fontSize = 32.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                    Text(
                        text = " $speedUnit",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = Color.White.copy(alpha = 0.7f),
                        modifier = Modifier.padding(bottom = 4.dp)
                    )
                }
                Text(
                    text = "$compassDirection ($windDirectionDeg°)",
                    style = MaterialTheme.typography.bodySmall,
                    fontWeight = FontWeight.Medium,
                    color = Color(0xFF4ADE80)
                )
                Text(
                    text = "Gusts to ${windGusts.roundToInt()} $speedUnit",
                    style = MaterialTheme.typography.labelSmall,
                    color = Color.White.copy(alpha = 0.6f)
                )
            }

            // Visual Compass Needle
            Box(
                modifier = Modifier
                    .size(54.dp)
                    .clip(CircleShape)
                    .background(Color.White.copy(alpha = 0.08f)),
                contentAlignment = Alignment.Center
            ) {
                Canvas(modifier = Modifier.fillMaxSize()) {
                    drawCircle(
                        color = Color.White.copy(alpha = 0.2f),
                        style = Stroke(width = 1.dp.toPx())
                    )
                }
                Icon(
                    imageVector = Icons.Filled.Navigation,
                    contentDescription = "Wind direction needle",
                    tint = Color(0xFF4ADE80),
                    modifier = Modifier
                        .size(24.dp)
                        .rotate(windDirectionDeg.toFloat())
                )
            }
        }
    }
}

@Composable
fun HumidityCard(
    humidityPercent: Int,
    comfortLabel: String,
    modifier: Modifier = Modifier
) {
    MetricContainer(
        title = "Humidity",
        icon = Icons.Filled.WaterDrop,
        iconTint = Color(0xFFA78BFA),
        modifier = modifier
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Row(verticalAlignment = Alignment.Bottom) {
                    Text(
                        text = "$humidityPercent",
                        fontSize = 32.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                    Text(
                        text = "%",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = Color(0xFFA78BFA),
                        modifier = Modifier.padding(bottom = 4.dp, start = 2.dp)
                    )
                }
                Text(
                    text = comfortLabel,
                    style = MaterialTheme.typography.bodySmall,
                    fontWeight = FontWeight.Medium,
                    color = Color.White.copy(alpha = 0.85f)
                )
                Text(
                    text = if (humidityPercent > 60) "High moisture" else "Optimum breathing",
                    style = MaterialTheme.typography.labelSmall,
                    color = Color.White.copy(alpha = 0.6f)
                )
            }

            // Circular Humidity Gauge
            Box(
                modifier = Modifier.size(50.dp),
                contentAlignment = Alignment.Center
            ) {
                Canvas(modifier = Modifier.fillMaxSize()) {
                    val stroke = 5.dp.toPx()
                    drawCircle(
                        color = Color.White.copy(alpha = 0.12f),
                        style = Stroke(stroke)
                    )
                    drawArc(
                        brush = Brush.sweepGradient(
                            listOf(Color(0xFF818CF8), Color(0xFFA78BFA))
                        ),
                        startAngle = -90f,
                        sweepAngle = (humidityPercent / 100f) * 360f,
                        useCenter = false,
                        style = Stroke(stroke, cap = StrokeCap.Round)
                    )
                }
                Text(
                    text = "$humidityPercent%",
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
            }
        }
    }
}

@Composable
fun SunriseSunsetCard(
    sunrise: String,
    sunset: String,
    modifier: Modifier = Modifier
) {
    MetricContainer(
        title = "Sun & Daylight",
        icon = Icons.Filled.WbSunny,
        iconTint = Color(0xFFFBBF24),
        modifier = modifier
    ) {
        Column(
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            // Sunrise
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Filled.WbSunny,
                        contentDescription = null,
                        tint = Color(0xFFFBBF24),
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "Sunrise",
                        style = MaterialTheme.typography.bodySmall,
                        color = Color.White.copy(alpha = 0.7f)
                    )
                }
                Text(
                    text = sunrise,
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
            }

            // Sunset
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Outlined.WbTwilight,
                        contentDescription = null,
                        tint = Color(0xFFFB923C),
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "Sunset",
                        style = MaterialTheme.typography.bodySmall,
                        color = Color.White.copy(alpha = 0.7f)
                    )
                }
                Text(
                    text = sunset,
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
            }
        }
    }
}

@Composable
fun AtmosphereCard(
    pressureHpa: Float,
    cloudCover: Int,
    modifier: Modifier = Modifier
) {
    MetricContainer(
        title = "Pressure & Clouds",
        icon = Icons.Filled.Compress,
        iconTint = Color(0xFF38BDF8),
        modifier = modifier
    ) {
        Column(
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = "Pressure",
                    style = MaterialTheme.typography.bodySmall,
                    color = Color.White.copy(alpha = 0.7f)
                )
                Text(
                    text = "${pressureHpa.roundToInt()} hPa",
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
            }

            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = "Cloud Cover",
                    style = MaterialTheme.typography.bodySmall,
                    color = Color.White.copy(alpha = 0.7f)
                )
                Text(
                    text = "$cloudCover%",
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
            }
        }
    }
}

@Composable
fun MetricContainer(
    title: String,
    icon: ImageVector,
    iconTint: Color,
    modifier: Modifier = Modifier,
    content: @Composable () -> Unit
) {
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(20.dp),
        color = Color(0xFF1E293B).copy(alpha = 0.75f),
        tonalElevation = 6.dp
    ) {
        Column(
            modifier = Modifier.padding(14.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.padding(bottom = 8.dp)
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = iconTint,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = title,
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.SemiBold,
                    color = Color.White.copy(alpha = 0.75f)
                )
            }
            content()
        }
    }
}
