package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Info
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.drawText
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.GraphMetricType
import com.example.data.model.HourlyDataPoint
import com.example.data.model.TemperatureUnit
import java.util.Locale
import kotlin.math.roundToInt

@Composable
fun InteractiveHourlyChart(
    hourlyPoints: List<HourlyDataPoint>,
    selectedPoint: HourlyDataPoint?,
    metric: GraphMetricType,
    unit: TemperatureUnit,
    onPointSelected: (HourlyDataPoint?) -> Unit,
    onMetricChanged: (GraphMetricType) -> Unit,
    modifier: Modifier = Modifier
) {
    if (hourlyPoints.isEmpty()) return

    // Ensure we have a working subset (e.g. 12-24 hours)
    val points = remember(hourlyPoints) {
        if (hourlyPoints.size > 24) hourlyPoints.take(24) else hourlyPoints
    }

    var touchX by remember { mutableFloatStateOf(-1f) }
    var isTouching by remember { mutableStateOf(false) }

    // Color schemes for each metric
    val (primaryColor, gradientColor) = when (metric) {
        GraphMetricType.TEMPERATURE -> Pair(Color(0xFFFFAA00), Color(0xFFFF7700))
        GraphMetricType.RAIN_CHANCE -> Pair(Color(0xFF38BDF8), Color(0xFF0284C7))
        GraphMetricType.WIND -> Pair(Color(0xFF4ADE80), Color(0xFF16A34A))
        GraphMetricType.HUMIDITY -> Pair(Color(0xFFA78BFA), Color(0xFF7C3AED))
        GraphMetricType.UV_INDEX -> Pair(Color(0xFFF472B6), Color(0xFFDB2777))
    }

    Surface(
        modifier = modifier
            .fillMaxWidth()
            .testTag("interactive_hourly_chart"),
        shape = RoundedCornerShape(24.dp),
        color = Color(0xFF1E293B).copy(alpha = 0.75f),
        tonalElevation = 6.dp
    ) {
        Column(
            modifier = Modifier.padding(16.dp)
        ) {
            // Header with title and touch hint
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "Hourly Forecast",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                    Text(
                        text = "Touch or drag across graph to inspect",
                        style = MaterialTheme.typography.bodySmall,
                        color = Color.White.copy(alpha = 0.6f)
                    )
                }

                // Selected point readout badge
                val inspectedPoint = selectedPoint ?: points.firstOrNull()
                if (inspectedPoint != null) {
                    val valueStr = when (metric) {
                        GraphMetricType.TEMPERATURE -> "${unit.convertTemp(inspectedPoint.temperatureC).roundToInt()}${unit.symbol}"
                        GraphMetricType.RAIN_CHANCE -> "${inspectedPoint.precipitationProbability}%"
                        GraphMetricType.WIND -> "${unit.convertSpeed(inspectedPoint.windSpeedKmh).roundToInt()} ${unit.speedUnit}"
                        GraphMetricType.HUMIDITY -> "${inspectedPoint.humidityPercent}%"
                        GraphMetricType.UV_INDEX -> String.format(Locale.US, "%.1f UV", inspectedPoint.uvIndex)
                    }

                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = primaryColor.copy(alpha = 0.2f),
                        border = androidx.compose.foundation.BorderStroke(1.dp, primaryColor.copy(alpha = 0.5f))
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = inspectedPoint.condition.iconDay,
                                contentDescription = null,
                                tint = primaryColor,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "${inspectedPoint.displayHour}: $valueStr",
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Metric Tabs row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                GraphMetricType.entries.forEach { m ->
                    val isSelected = m == metric
                    FilterChip(
                        selected = isSelected,
                        onClick = { onMetricChanged(m) },
                        label = {
                            Text(
                                text = m.label,
                                fontSize = 12.sp,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                            )
                        },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = primaryColor.copy(alpha = 0.3f),
                            selectedLabelColor = Color.White,
                            containerColor = Color.White.copy(alpha = 0.05f),
                            labelColor = Color.White.copy(alpha = 0.7f)
                        ),
                        border = FilterChipDefaults.filterChipBorder(
                            enabled = true,
                            selected = isSelected,
                            borderColor = if (isSelected) primaryColor else Color.White.copy(alpha = 0.15f)
                        ),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("metric_chip_${m.name.lowercase()}")
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Graph Canvas with touch handler
            val textMeasurer = rememberTextMeasurer()

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(160.dp)
            ) {
                Canvas(
                    modifier = Modifier
                        .matchParentSize()
                        .pointerInput(points, metric) {
                            detectTapGestures(
                                onPress = { offset ->
                                    isTouching = true
                                    touchX = offset.x
                                    val stepWidth = size.width / (points.size - 1).coerceAtLeast(1)
                                    val index = (offset.x / stepWidth).roundToInt().coerceIn(0, points.size - 1)
                                    onPointSelected(points[index])
                                    tryAwaitRelease()
                                    isTouching = false
                                }
                            )
                        }
                        .pointerInput(points, metric) {
                            detectDragGestures(
                                onDragStart = { offset ->
                                    isTouching = true
                                    touchX = offset.x
                                    val stepWidth = size.width / (points.size - 1).coerceAtLeast(1)
                                    val index = (offset.x / stepWidth).roundToInt().coerceIn(0, points.size - 1)
                                    onPointSelected(points[index])
                                },
                                onDragEnd = {
                                    isTouching = false
                                },
                                onDragCancel = {
                                    isTouching = false
                                },
                                onDrag = { change, _ ->
                                    change.consume()
                                    touchX = change.position.x
                                    val stepWidth = size.width / (points.size - 1).coerceAtLeast(1)
                                    val index = (change.position.x / stepWidth).roundToInt().coerceIn(0, points.size - 1)
                                    onPointSelected(points[index])
                                }
                            )
                        }
                ) {
                    val width = size.width
                    val height = size.height
                    val bottomPadding = 28f
                    val topPadding = 24f
                    val chartHeight = height - bottomPadding - topPadding

                    // Extract values according to active metric
                    val rawValues = points.map { pt ->
                        when (metric) {
                            GraphMetricType.TEMPERATURE -> unit.convertTemp(pt.temperatureC)
                            GraphMetricType.RAIN_CHANCE -> pt.precipitationProbability.toFloat()
                            GraphMetricType.WIND -> unit.convertSpeed(pt.windSpeedKmh)
                            GraphMetricType.HUMIDITY -> pt.humidityPercent.toFloat()
                            GraphMetricType.UV_INDEX -> pt.uvIndex
                        }
                    }

                    val minValue = when (metric) {
                        GraphMetricType.RAIN_CHANCE, GraphMetricType.HUMIDITY -> 0f
                        GraphMetricType.UV_INDEX -> 0f
                        else -> (rawValues.minOrNull() ?: 0f) - 2f
                    }
                    val maxValue = when (metric) {
                        GraphMetricType.RAIN_CHANCE, GraphMetricType.HUMIDITY -> 100f
                        GraphMetricType.UV_INDEX -> maxOf(10f, (rawValues.maxOrNull() ?: 5f) + 1f)
                        else -> (rawValues.maxOrNull() ?: 30f) + 2f
                    }
                    val valueRange = (maxValue - minValue).coerceAtLeast(1f)

                    val stepX = width / (points.size - 1).coerceAtLeast(1)

                    // Draw subtle horizontal grid lines (3 lines)
                    val gridSteps = 3
                    for (g in 0..gridSteps) {
                        val gridY = topPadding + chartHeight * (1f - g.toFloat() / gridSteps)
                        drawLine(
                            color = Color.White.copy(alpha = 0.08f),
                            start = Offset(0f, gridY),
                            end = Offset(width, gridY),
                            strokeWidth = 1f,
                            pathEffect = PathEffect.dashPathEffect(floatArrayOf(8f, 8f))
                        )
                    }

                    // Calculate curve points
                    val screenPoints = points.indices.map { i ->
                        val x = i * stepX
                        val normalized = ((rawValues[i] - minValue) / valueRange).coerceIn(0f, 1f)
                        val y = topPadding + chartHeight * (1f - normalized)
                        Offset(x, y)
                    }

                    // Build smooth Cubic Bezier Path
                    val strokePath = Path()
                    val fillPath = Path()

                    if (screenPoints.isNotEmpty()) {
                        strokePath.moveTo(screenPoints.first().x, screenPoints.first().y)
                        fillPath.moveTo(screenPoints.first().x, height - bottomPadding)
                        fillPath.lineTo(screenPoints.first().x, screenPoints.first().y)

                        for (i in 0 until screenPoints.size - 1) {
                            val p0 = screenPoints[i]
                            val p1 = screenPoints[i + 1]
                            val controlX1 = p0.x + (p1.x - p0.x) / 2f
                            val controlY1 = p0.y
                            val controlX2 = p0.x + (p1.x - p0.x) / 2f
                            val controlY2 = p1.y

                            strokePath.cubicTo(controlX1, controlY1, controlX2, controlY2, p1.x, p1.y)
                            fillPath.cubicTo(controlX1, controlY1, controlX2, controlY2, p1.x, p1.y)
                        }

                        fillPath.lineTo(screenPoints.last().x, height - bottomPadding)
                        fillPath.close()

                        // Draw gradient area under curve
                        drawPath(
                            path = fillPath,
                            brush = Brush.verticalGradient(
                                colors = listOf(
                                    primaryColor.copy(alpha = 0.35f),
                                    gradientColor.copy(alpha = 0.12f),
                                    Color.Transparent
                                ),
                                startY = topPadding,
                                endY = height - bottomPadding
                            )
                        )

                        // Draw smooth main line
                        drawPath(
                            path = strokePath,
                            brush = Brush.horizontalGradient(
                                colors = listOf(primaryColor, gradientColor)
                            ),
                            style = Stroke(width = 3.5.dp.toPx(), cap = StrokeCap.Round)
                        )
                    }

                    // Draw time labels along bottom every 3 or 4 points
                    val labelInterval = when {
                        points.size <= 8 -> 1
                        points.size <= 16 -> 2
                        else -> 3
                    }

                    for (i in points.indices step labelInterval) {
                        val pt = points[i]
                        val x = i * stepX
                        val text = pt.displayHour
                        val measured = textMeasurer.measure(
                            text = text,
                            style = TextStyle(
                                color = Color.White.copy(alpha = 0.65f),
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Medium
                            )
                        )
                        val textX = (x - measured.size.width / 2f).coerceIn(0f, width - measured.size.width)
                        drawText(
                            textLayoutResult = measured,
                            topLeft = Offset(textX, height - bottomPadding + 8f)
                        )
                    }

                    // Draw active/touched node and vertical guideline
                    val activeIndex = when {
                        isTouching && touchX >= 0f -> {
                            (touchX / stepX).roundToInt().coerceIn(0, points.size - 1)
                        }
                        selectedPoint != null -> {
                            points.indexOfFirst { it.timeIso == selectedPoint.timeIso }.coerceAtLeast(0)
                        }
                        else -> 0
                    }

                    if (activeIndex in screenPoints.indices) {
                        val selectedScreenPoint = screenPoints[activeIndex]

                        // Draw vertical guideline
                        drawLine(
                            color = primaryColor.copy(alpha = 0.8f),
                            start = Offset(selectedScreenPoint.x, topPadding),
                            end = Offset(selectedScreenPoint.x, height - bottomPadding),
                            strokeWidth = 2.dp.toPx(),
                            pathEffect = PathEffect.dashPathEffect(floatArrayOf(6f, 6f))
                        )

                        // Outer glowing circle
                        drawCircle(
                            color = primaryColor.copy(alpha = 0.35f),
                            radius = 10.dp.toPx(),
                            center = selectedScreenPoint
                        )

                        // Middle white circle
                        drawCircle(
                            color = Color.White,
                            radius = 5.dp.toPx(),
                            center = selectedScreenPoint
                        )

                        // Center colored dot
                        drawCircle(
                            color = primaryColor,
                            radius = 3.dp.toPx(),
                            center = selectedScreenPoint
                        )
                    }
                }
            }
        }
    }
}
