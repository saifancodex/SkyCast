package com.example.ui.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CalendarToday
import androidx.compose.material.icons.filled.WaterDrop
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.DailyForecastDay
import com.example.data.model.TemperatureUnit
import kotlin.math.roundToInt

@Composable
fun DailyForecastCard(
    forecastDays: List<DailyForecastDay>,
    selectedIndex: Int,
    unit: TemperatureUnit,
    onDaySelected: (Int) -> Unit,
    modifier: Modifier = Modifier
) {
    if (forecastDays.isEmpty()) return

    // Calculate global min and max for the 5-day range to make visual bars accurate
    val globalMin = forecastDays.minOfOrNull { it.tempMinC } ?: 10f
    val globalMax = forecastDays.maxOfOrNull { it.tempMaxC } ?: 30f
    val globalSpan = (globalMax - globalMin).coerceAtLeast(1f)

    Surface(
        modifier = modifier
            .fillMaxWidth()
            .testTag("five_day_forecast_card"),
        shape = RoundedCornerShape(24.dp),
        color = Color(0xFF1E293B).copy(alpha = 0.75f),
        tonalElevation = 6.dp
    ) {
        Column(
            modifier = Modifier.padding(16.dp)
        ) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Filled.CalendarToday,
                        contentDescription = null,
                        tint = Color(0xFF60A5FA),
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "5-Day Forecast",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                }

                Text(
                    text = "Tap to view hourly",
                    style = MaterialTheme.typography.labelSmall,
                    color = Color.White.copy(alpha = 0.6f)
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Forecast Days List
            forecastDays.take(5).forEachIndexed { index, day ->
                val isSelected = index == selectedIndex
                val backgroundColor by animateColorAsState(
                    targetValue = if (isSelected) Color(0xFF334155).copy(alpha = 0.8f) else Color.Transparent,
                    label = "day_bg"
                )

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(16.dp))
                        .background(backgroundColor)
                        .then(
                            if (isSelected) {
                                Modifier.border(
                                    1.dp,
                                    Color(0xFF60A5FA).copy(alpha = 0.7f),
                                    RoundedCornerShape(16.dp)
                                )
                            } else Modifier
                        )
                        .clickable { onDaySelected(index) }
                        .padding(horizontal = 12.dp, vertical = 10.dp)
                        .testTag("forecast_day_row_$index"),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    // Day of week & date
                    Column(
                        modifier = Modifier.width(78.dp)
                    ) {
                        Text(
                            text = day.dayOfWeek,
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                            color = if (isSelected) Color.White else Color.White.copy(alpha = 0.9f)
                        )
                        Text(
                            text = day.shortDate,
                            style = MaterialTheme.typography.labelSmall,
                            color = Color.White.copy(alpha = 0.55f)
                        )
                    }

                    // Condition icon & rain probability
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.width(72.dp)
                    ) {
                        Icon(
                            imageVector = day.condition.iconDay,
                            contentDescription = day.condition.description,
                            tint = day.condition.accentColor,
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        if (day.precipitationProbabilityMax > 0) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Filled.WaterDrop,
                                    contentDescription = "Rain chance",
                                    tint = Color(0xFF38BDF8),
                                    modifier = Modifier.size(12.dp)
                                )
                                Text(
                                    text = "${day.precipitationProbabilityMax}%",
                                    fontSize = 11.sp,
                                    color = Color(0xFF38BDF8),
                                    fontWeight = FontWeight.SemiBold
                                )
                            }
                        }
                    }

                    // Temperature Range Visual Bar
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.weight(1f),
                        horizontalArrangement = Arrangement.End
                    ) {
                        // Min temp
                        Text(
                            text = "${unit.convertTemp(day.tempMinC).roundToInt()}°",
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.Medium,
                            color = Color.White.copy(alpha = 0.65f),
                            modifier = Modifier.width(32.dp)
                        )

                        // Bar
                        val leftFrac = ((day.tempMinC - globalMin) / globalSpan).coerceIn(0f, 1f)
                        val rightFrac = ((day.tempMaxC - globalMin) / globalSpan).coerceIn(0f, 1f)
                        val barWidth = (rightFrac - leftFrac).coerceAtLeast(0.12f)

                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .height(6.dp)
                                .padding(horizontal = 6.dp)
                                .clip(CircleShape)
                                .background(Color.White.copy(alpha = 0.12f))
                        ) {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth(barWidth)
                                    .height(6.dp)
                                    .align(Alignment.CenterStart)
                                    .clip(CircleShape)
                                    .background(
                                        Brush.horizontalGradient(
                                            listOf(
                                                Color(0xFF38BDF8),
                                                Color(0xFFFBBF24),
                                                Color(0xFFF97316)
                                            )
                                        )
                                    )
                            )
                        }

                        // Max temp
                        Text(
                            text = "${unit.convertTemp(day.tempMaxC).roundToInt()}°",
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.Bold,
                            color = Color.White,
                            modifier = Modifier.width(32.dp)
                        )
                    }
                }

                if (index < 4) {
                    Spacer(modifier = Modifier.height(4.dp))
                }
            }
        }
    }
}
