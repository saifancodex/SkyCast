package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val SkyBluePrimary = Color(0xFF60A5FA)
val SkyBlueSecondary = Color(0xFF38BDF8)
val SkyAmberAccent = Color(0xFFFBBF24)
val SkyDarkBackground = Color(0xFF0F172A)
val SkyDarkSurface = Color(0xFF1E293B)
val SkyDarkSurfaceVariant = Color(0xFF334155)

val SkyLightPrimary = Color(0xFF0284C7)
val SkyLightSecondary = Color(0xFF0369A1)
val SkyLightBackground = Color(0xFFF8FAFC)
val SkyLightSurface = Color(0xFFFFFFFF)
