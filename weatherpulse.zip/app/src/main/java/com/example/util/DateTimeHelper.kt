package com.example.util

import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.TimeZone

object DateTimeHelper {

    fun getPlaceZonedInfo(timezoneStr: String): PlaceTimeInfo {
        val timeZone = try {
            if (timezoneStr.isNotBlank() && timezoneStr != "auto") {
                TimeZone.getTimeZone(timezoneStr)
            } else {
                TimeZone.getDefault()
            }
        } catch (_: Exception) {
            TimeZone.getDefault()
        }

        val now = Date()

        val timeFormat = SimpleDateFormat("h:mm a", Locale.getDefault()).apply {
            this.timeZone = timeZone
        }
        val dateFormat = SimpleDateFormat("EEEE, MMMM d", Locale.getDefault()).apply {
            this.timeZone = timeZone
        }
        val shortDateFormat = SimpleDateFormat("MMM d, yyyy", Locale.getDefault()).apply {
            this.timeZone = timeZone
        }

        // Calculate offset in hours
        val offsetMillis = timeZone.getOffset(now.time)
        val offsetHours = offsetMillis / (1000 * 60 * 60)
        val offsetMinutes = Math.abs((offsetMillis / (1000 * 60)) % 60)
        val offsetString = if (offsetHours >= 0) {
            String.format(Locale.US, "GMT+%d:%02d", offsetHours, offsetMinutes)
        } else {
            String.format(Locale.US, "GMT%d:%02d", offsetHours, offsetMinutes)
        }

        val tzDisplayName = timeZone.getDisplayName(timeZone.inDaylightTime(now), TimeZone.SHORT, Locale.getDefault())

        return PlaceTimeInfo(
            formattedTime = timeFormat.format(now),
            formattedDate = dateFormat.format(now),
            shortDate = shortDateFormat.format(now),
            timezoneDisplayName = "$tzDisplayName ($offsetString)",
            offsetHours = offsetHours
        )
    }

    fun parseHourDisplay(isoString: String, index: Int): String {
        return try {
            // ISO format: 2026-11-10T14:00
            val parts = isoString.split("T")
            if (parts.size >= 2) {
                val timeParts = parts[1].split(":")
                val hour = timeParts[0].toIntOrNull() ?: 0
                when {
                    index == 0 -> "Now"
                    hour == 0 -> "12 AM"
                    hour == 12 -> "12 PM"
                    hour > 12 -> "${hour - 12} PM"
                    else -> "$hour AM"
                }
            } else {
                isoString
            }
        } catch (_: Exception) {
            isoString
        }
    }

    fun parseDayDisplay(isoString: String, dayIndex: Int): Pair<String, String> {
        return try {
            // ISO format: 2026-11-10
            val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.US)
            val date = sdf.parse(isoString) ?: Date()
            val dayOfWeekFormat = SimpleDateFormat("EEE", Locale.getDefault())
            val shortDateFormat = SimpleDateFormat("MMM d", Locale.getDefault())

            val dayName = when (dayIndex) {
                0 -> "Today"
                1 -> "Tomorrow"
                else -> dayOfWeekFormat.format(date)
            }
            Pair(dayName, shortDateFormat.format(date))
        } catch (_: Exception) {
            Pair(if (dayIndex == 0) "Today" else "Day $dayIndex", isoString)
        }
    }

    fun formatSunTime(isoString: String?): String {
        if (isoString.isNullOrBlank()) return "--:--"
        return try {
            val parts = isoString.split("T")
            if (parts.size >= 2) {
                val timeParts = parts[1].split(":")
                val hour = timeParts[0].toIntOrNull() ?: 0
                val min = timeParts.getOrNull(1)?.toIntOrNull() ?: 0
                val amPm = if (hour >= 12) "PM" else "AM"
                val displayHour = when {
                    hour == 0 -> 12
                    hour > 12 -> hour - 12
                    else -> hour
                }
                String.format(Locale.US, "%d:%02d %s", displayHour, min, amPm)
            } else {
                isoString
            }
        } catch (_: Exception) {
            isoString
        }
    }
}

data class PlaceTimeInfo(
    val formattedTime: String,
    val formattedDate: String,
    val shortDate: String,
    val timezoneDisplayName: String,
    val offsetHours: Int
)
