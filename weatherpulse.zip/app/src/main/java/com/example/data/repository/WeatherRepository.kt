package com.example.data.repository

import com.example.data.CityDatabase
import com.example.data.api.ApiClient
import com.example.data.api.dto.OpenMeteoForecastResponse
import com.example.data.model.CityLocation
import com.example.data.model.CurrentWeatherData
import com.example.data.model.DailyForecastDay
import com.example.data.model.HourlyDataPoint
import com.example.data.model.WeatherCondition
import com.example.util.DateTimeHelper
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.TimeZone

class WeatherRepository {

    private val api = ApiClient.service
    private val favoriteCityIds = mutableSetOf("tokyo", "new_york", "london")

    fun isFavorite(cityId: String): Boolean = favoriteCityIds.contains(cityId)

    fun toggleFavorite(city: CityLocation): Boolean {
        val id = if (city.id.isNotBlank()) city.id else "${city.name.lowercase()}_${city.country.lowercase()}"
        return if (favoriteCityIds.contains(id)) {
            favoriteCityIds.remove(id)
            false
        } else {
            favoriteCityIds.add(id)
            true
        }
    }

    suspend fun fetchWeather(location: CityLocation): CurrentWeatherData = withContext(Dispatchers.IO) {
        try {
            val response = api.getForecast(
                latitude = location.latitude,
                longitude = location.longitude
            )
            mapResponseToWeather(response, location)
        } catch (e: Exception) {
            // Return realistic fallback weather based on location
            generateFallbackWeather(location)
        }
    }

    suspend fun searchCities(query: String): List<CityLocation> = withContext(Dispatchers.IO) {
        if (query.isBlank()) return@withContext CityDatabase.POPULAR_CITIES

        val localMatches = CityDatabase.POPULAR_CITIES.filter {
            it.name.contains(query, ignoreCase = true) ||
                    it.country.contains(query, ignoreCase = true) ||
                    (it.admin1?.contains(query, ignoreCase = true) == true)
        }

        try {
            val remoteResults = api.searchCities(query = query.trim())
            val mappedRemote = remoteResults.results?.map { geo ->
                val id = "${geo.name.lowercase()}_${geo.countryCode ?: geo.country ?: "geo"}"
                CityLocation(
                    id = id,
                    name = geo.name,
                    country = geo.country ?: "",
                    countryCode = geo.countryCode,
                    admin1 = geo.admin1,
                    latitude = geo.latitude,
                    longitude = geo.longitude,
                    timezone = geo.timezone ?: locationToTimezone(geo.latitude, geo.longitude),
                    isFavorite = isFavorite(id)
                )
            } ?: emptyList()

            // Merge unique by name + country
            val combined = (localMatches + mappedRemote).distinctBy { "${it.name}_${it.country}" }
            if (combined.isNotEmpty()) combined else localMatches
        } catch (_: Exception) {
            localMatches
        }
    }

    private fun mapResponseToWeather(
        response: OpenMeteoForecastResponse,
        location: CityLocation
    ): CurrentWeatherData {
        val tz = response.timezone ?: location.timezone
        val timeInfo = DateTimeHelper.getPlaceZonedInfo(tz)

        val current = response.current
        val weatherCode = current?.weatherCode ?: 0
        val condition = WeatherCondition.fromWmoCode(weatherCode)

        // Parse hourly points
        val allHourly = mutableListOf<HourlyDataPoint>()
        val hourlyTimes = response.hourly?.time ?: emptyList()
        val hourlyTemps = response.hourly?.temperature ?: emptyList()
        val hourlyPrecipProb = response.hourly?.precipitationProbability ?: emptyList()
        val hourlyPrecip = response.hourly?.precipitation ?: emptyList()
        val hourlyHum = response.hourly?.relativeHumidity ?: emptyList()
        val hourlyWind = response.hourly?.windSpeed ?: emptyList()
        val hourlyWindDir = response.hourly?.windDirection ?: emptyList()
        val hourlyUv = response.hourly?.uvIndex ?: emptyList()
        val hourlyCodes = response.hourly?.weatherCode ?: emptyList()
        val hourlyIsDay = response.hourly?.isDay ?: emptyList()

        for (i in hourlyTimes.indices) {
            val tIso = hourlyTimes.getOrNull(i) ?: ""
            val hourOfDay = try {
                tIso.split("T").getOrNull(1)?.split(":")?.getOrNull(0)?.toIntOrNull() ?: (i % 24)
            } catch (_: Exception) { i % 24 }

            val code = hourlyCodes.getOrNull(i) ?: 0
            val pointCondition = WeatherCondition.fromWmoCode(code)

            allHourly.add(
                HourlyDataPoint(
                    timeIso = tIso,
                    displayHour = DateTimeHelper.parseHourDisplay(tIso, i),
                    hourOfDay = hourOfDay,
                    temperatureC = hourlyTemps.getOrNull(i) ?: 20f,
                    precipitationProbability = hourlyPrecipProb.getOrNull(i) ?: 0,
                    precipitationMm = hourlyPrecip.getOrNull(i) ?: 0f,
                    humidityPercent = hourlyHum.getOrNull(i) ?: 50,
                    windSpeedKmh = hourlyWind.getOrNull(i) ?: 10f,
                    windDirectionDeg = hourlyWindDir.getOrNull(i) ?: 0,
                    uvIndex = hourlyUv.getOrNull(i) ?: 0f,
                    weatherCode = code,
                    condition = pointCondition,
                    isDay = (hourlyIsDay.getOrNull(i) ?: 1) == 1
                )
            )
        }

        // Parse daily forecast (up to 7 days, take 5)
        val dailyTimes = response.daily?.time ?: emptyList()
        val dailyCodes = response.daily?.weatherCode ?: emptyList()
        val dailyMaxTemps = response.daily?.temperatureMax ?: emptyList()
        val dailyMinTemps = response.daily?.temperatureMin ?: emptyList()
        val dailyPrecipProb = response.daily?.precipitationProbabilityMax ?: emptyList()
        val dailyPrecipSum = response.daily?.precipitationSum ?: emptyList()
        val dailyUvMax = response.daily?.uvIndexMax ?: emptyList()
        val dailyWindMax = response.daily?.windSpeedMax ?: emptyList()
        val dailySunrises = response.daily?.sunrise ?: emptyList()
        val dailySunsets = response.daily?.sunset ?: emptyList()

        val fiveDayList = mutableListOf<DailyForecastDay>()
        val dayCount = minOf(dailyTimes.size, 5)

        for (d in 0 until dayCount) {
            val dateIso = dailyTimes[d]
            val (dayOfWeek, shortDate) = DateTimeHelper.parseDayDisplay(dateIso, d)
            val dCode = dailyCodes.getOrNull(d) ?: weatherCode
            val dCondition = WeatherCondition.fromWmoCode(dCode)

            // 24 hours chunk for this day
            val dayHourlyPoints = allHourly.filter { it.timeIso.startsWith(dateIso) }
                .ifEmpty {
                    val startIdx = d * 24
                    val endIdx = minOf(startIdx + 24, allHourly.size)
                    if (startIdx < allHourly.size) allHourly.subList(startIdx, endIdx) else emptyList()
                }

            fiveDayList.add(
                DailyForecastDay(
                    dateIso = dateIso,
                    dayOfWeek = dayOfWeek,
                    shortDate = shortDate,
                    weatherCode = dCode,
                    condition = dCondition,
                    tempMaxC = dailyMaxTemps.getOrNull(d) ?: 22f,
                    tempMinC = dailyMinTemps.getOrNull(d) ?: 14f,
                    precipitationProbabilityMax = dailyPrecipProb.getOrNull(d) ?: 10,
                    precipitationSumMm = dailyPrecipSum.getOrNull(d) ?: 0f,
                    uvIndexMax = dailyUvMax.getOrNull(d) ?: 5f,
                    windSpeedMaxKmh = dailyWindMax.getOrNull(d) ?: 15f,
                    sunriseTime = DateTimeHelper.formatSunTime(dailySunrises.getOrNull(d)),
                    sunsetTime = DateTimeHelper.formatSunTime(dailySunsets.getOrNull(d)),
                    hourlyPoints = dayHourlyPoints
                )
            )
        }

        // Today's hourly window: next 24 hours starting from current local hour or first 24
        val todayHourly = if (allHourly.size >= 24) allHourly.take(24) else allHourly

        return CurrentWeatherData(
            location = location.copy(timezone = tz, isFavorite = isFavorite(location.id)),
            temperatureC = current?.temperature ?: 21f,
            apparentTemperatureC = current?.apparentTemperature ?: (current?.temperature ?: 21f),
            weatherCode = weatherCode,
            condition = condition,
            humidityPercent = current?.relativeHumidity ?: 60,
            precipitationProbability = todayHourly.firstOrNull()?.precipitationProbability ?: 10,
            precipitationMm = current?.precipitation ?: 0f,
            windSpeedKmh = current?.windSpeed ?: 12f,
            windDirectionDeg = current?.windDirection ?: 180,
            windGustsKmh = current?.windGusts ?: (current?.windSpeed ?: 12f) * 1.3f,
            uvIndex = current?.uvIndex ?: (fiveDayList.firstOrNull()?.uvIndexMax ?: 4.5f),
            pressureHpa = current?.pressureMsl ?: 1013.2f,
            cloudCoverPercent = current?.cloudCover ?: 30,
            isDay = (current?.isDay ?: 1) == 1,
            tempMinC = fiveDayList.firstOrNull()?.tempMinC ?: 15f,
            tempMaxC = fiveDayList.firstOrNull()?.tempMaxC ?: 24f,
            formattedDate = timeInfo.formattedDate,
            formattedTime = timeInfo.formattedTime,
            timezoneOffsetHours = timeInfo.offsetHours,
            sunriseTime = fiveDayList.firstOrNull()?.sunriseTime ?: "06:30 AM",
            sunsetTime = fiveDayList.firstOrNull()?.sunsetTime ?: "06:15 PM",
            hourlyForecast = todayHourly,
            fiveDayForecast = fiveDayList
        )
    }

    fun generateFallbackWeather(location: CityLocation): CurrentWeatherData {
        val timeInfo = DateTimeHelper.getPlaceZonedInfo(location.timezone)

        // Generate location-characteristic temperature
        val baseTemp = when {
            location.latitude > 45.0 -> 12f
            location.latitude < -25.0 -> 24f
            location.latitude in 0.0..30.0 -> 28f
            else -> 19f
        }

        val condition = WeatherCondition.PARTLY_CLOUDY
        val hourlyList = mutableListOf<HourlyDataPoint>()

        for (h in 0 until 24) {
            val hourOfDay = h
            val tempVariation = Math.sin((h - 8) * Math.PI / 12).toFloat() * 4f
            val temp = baseTemp + tempVariation
            val rainChance = (15 + Math.sin(h * 0.5) * 10).toInt().coerceIn(0, 100)
            val isDay = h in 6..19

            val hourStr = when {
                h == 0 -> "Now"
                h == 12 -> "12 PM"
                h > 12 -> "${h - 12} PM"
                else -> "$h AM"
            }

            hourlyList.add(
                HourlyDataPoint(
                    timeIso = "2026-11-10T${String.format(Locale.US, "%02d:00", h)}",
                    displayHour = hourStr,
                    hourOfDay = hourOfDay,
                    temperatureC = temp,
                    precipitationProbability = rainChance,
                    precipitationMm = if (rainChance > 40) 1.2f else 0.0f,
                    humidityPercent = (55 + Math.cos(h * 0.4) * 15).toInt().coerceIn(30, 95),
                    windSpeedKmh = (12f + (h % 5) * 2f),
                    windDirectionDeg = (180 + h * 5) % 360,
                    uvIndex = if (isDay) (Math.sin((h - 6) * Math.PI / 13) * 7.5).toFloat().coerceAtLeast(0f) else 0f,
                    weatherCode = if (rainChance > 50) 61 else 2,
                    condition = if (rainChance > 50) WeatherCondition.RAIN else WeatherCondition.PARTLY_CLOUDY,
                    isDay = isDay
                )
            )
        }

        val days = listOf("Today", "Tomorrow", "Thursday", "Friday", "Saturday")
        val fiveDayForecast = days.mapIndexed { idx, dayName ->
            val dayOffset = (idx * 1.5f) - 2f
            DailyForecastDay(
                dateIso = "2026-11-${10 + idx}",
                dayOfWeek = dayName,
                shortDate = "Nov ${10 + idx}",
                weatherCode = 2,
                condition = if (idx == 2) WeatherCondition.RAIN else WeatherCondition.PARTLY_CLOUDY,
                tempMaxC = baseTemp + 4f + dayOffset,
                tempMinC = baseTemp - 3f + dayOffset,
                precipitationProbabilityMax = if (idx == 2) 75 else 20 + idx * 5,
                precipitationSumMm = if (idx == 2) 8.5f else 0.2f,
                uvIndexMax = 6.2f,
                windSpeedMaxKmh = 18f,
                sunriseTime = "06:28 AM",
                sunsetTime = "05:42 PM",
                hourlyPoints = hourlyList
            )
        }

        return CurrentWeatherData(
            location = location.copy(isFavorite = isFavorite(location.id)),
            temperatureC = baseTemp + 1f,
            apparentTemperatureC = baseTemp,
            weatherCode = 2,
            condition = condition,
            humidityPercent = 64,
            precipitationProbability = 20,
            precipitationMm = 0.0f,
            windSpeedKmh = 14f,
            windDirectionDeg = 210,
            windGustsKmh = 22f,
            uvIndex = 5.2f,
            pressureHpa = 1014.5f,
            cloudCoverPercent = 40,
            isDay = true,
            tempMinC = baseTemp - 3f,
            tempMaxC = baseTemp + 4f,
            formattedDate = timeInfo.formattedDate,
            formattedTime = timeInfo.formattedTime,
            timezoneOffsetHours = timeInfo.offsetHours,
            sunriseTime = "06:28 AM",
            sunsetTime = "05:42 PM",
            hourlyForecast = hourlyList,
            fiveDayForecast = fiveDayForecast
        )
    }

    private fun locationToTimezone(lat: Double, lon: Double): String {
        return when {
            lat in 24.0..50.0 && lon in -125.0..-65.0 -> "America/New_York"
            lat in 35.0..70.0 && lon in -10.0..40.0 -> "Europe/London"
            lat in 20.0..50.0 && lon in 100.0..150.0 -> "Asia/Tokyo"
            lat in -45.0..-10.0 && lon in 110.0..160.0 -> "Australia/Sydney"
            else -> "UTC"
        }
    }
}
