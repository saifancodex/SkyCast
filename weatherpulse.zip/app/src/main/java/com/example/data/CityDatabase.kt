package com.example.data

import com.example.data.model.CityLocation

object CityDatabase {
    val POPULAR_CITIES = listOf(
        CityLocation(
            id = "tokyo",
            name = "Tokyo",
            country = "Japan",
            countryCode = "JP",
            latitude = 35.6762,
            longitude = 139.6503,
            timezone = "Asia/Tokyo",
            isFavorite = true
        ),
        CityLocation(
            id = "new_york",
            name = "New York",
            country = "United States",
            countryCode = "US",
            admin1 = "New York",
            latitude = 40.7128,
            longitude = -74.0060,
            timezone = "America/New_York",
            isFavorite = true
        ),
        CityLocation(
            id = "london",
            name = "London",
            country = "United Kingdom",
            countryCode = "GB",
            latitude = 51.5074,
            longitude = -0.1278,
            timezone = "Europe/London",
            isFavorite = true
        ),
        CityLocation(
            id = "paris",
            name = "Paris",
            country = "France",
            countryCode = "FR",
            latitude = 48.8566,
            longitude = 2.3522,
            timezone = "Europe/Paris",
            isFavorite = false
        ),
        CityLocation(
            id = "sydney",
            name = "Sydney",
            country = "Australia",
            countryCode = "AU",
            admin1 = "New South Wales",
            latitude = -33.8688,
            longitude = 151.2093,
            timezone = "Australia/Sydney",
            isFavorite = false
        ),
        CityLocation(
            id = "dubai",
            name = "Dubai",
            country = "United Arab Emirates",
            countryCode = "AE",
            latitude = 25.2048,
            longitude = 55.2708,
            timezone = "Asia/Dubai",
            isFavorite = false
        ),
        CityLocation(
            id = "san_francisco",
            name = "San Francisco",
            country = "United States",
            countryCode = "US",
            admin1 = "California",
            latitude = 37.7749,
            longitude = -122.4194,
            timezone = "America/Los_Angeles",
            isFavorite = false
        ),
        CityLocation(
            id = "singapore",
            name = "Singapore",
            country = "Singapore",
            countryCode = "SG",
            latitude = 1.3521,
            longitude = 103.8198,
            timezone = "Asia/Singapore",
            isFavorite = false
        ),
        CityLocation(
            id = "berlin",
            name = "Berlin",
            country = "Germany",
            countryCode = "DE",
            latitude = 52.5200,
            longitude = 13.4050,
            timezone = "Europe/Berlin",
            isFavorite = false
        ),
        CityLocation(
            id = "toronto",
            name = "Toronto",
            country = "Canada",
            countryCode = "CA",
            admin1 = "Ontario",
            latitude = 43.6532,
            longitude = -79.3832,
            timezone = "America/Toronto",
            isFavorite = false
        ),
        CityLocation(
            id = "cairo",
            name = "Cairo",
            country = "Egypt",
            countryCode = "EG",
            latitude = 30.0444,
            longitude = 31.2357,
            timezone = "Africa/Cairo",
            isFavorite = false
        ),
        CityLocation(
            id = "mumbai",
            name = "Mumbai",
            country = "India",
            countryCode = "IN",
            admin1 = "Maharashtra",
            latitude = 19.0760,
            longitude = 72.8777,
            timezone = "Asia/Kolkata",
            isFavorite = false
        ),
        CityLocation(
            id = "dhaka",
            name = "Dhaka",
            country = "Bangladesh",
            countryCode = "BD",
            latitude = 23.8103,
            longitude = 90.4125,
            timezone = "Asia/Dhaka",
            isFavorite = false
        ),
        CityLocation(
            id = "sao_paulo",
            name = "São Paulo",
            country = "Brazil",
            countryCode = "BR",
            admin1 = "Sao Paulo",
            latitude = -23.5505,
            longitude = -46.6333,
            timezone = "America/Sao_Paulo",
            isFavorite = false
        )
    )

    fun defaultCity(): CityLocation = POPULAR_CITIES[0] // Tokyo or New York
}
