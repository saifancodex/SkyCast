package com.example.data.api.dto

import com.squareup.moshi.Json
import com.squareup.moshi.JsonClass

@JsonClass(generateAdapter = true)
data class OpenMeteoForecastResponse(
    @Json(name = "latitude") val latitude: Double? = null,
    @Json(name = "longitude") val longitude: Double? = null,
    @Json(name = "timezone") val timezone: String? = null,
    @Json(name = "utc_offset_seconds") val utcOffsetSeconds: Int? = null,
    @Json(name = "current") val current: OpenMeteoCurrent? = null,
    @Json(name = "hourly") val hourly: OpenMeteoHourly? = null,
    @Json(name = "daily") val daily: OpenMeteoDaily? = null
)

@JsonClass(generateAdapter = true)
data class OpenMeteoCurrent(
    @Json(name = "time") val time: String? = null,
    @Json(name = "temperature_2m") val temperature: Float? = null,
    @Json(name = "relative_humidity_2m") val relativeHumidity: Int? = null,
    @Json(name = "apparent_temperature") val apparentTemperature: Float? = null,
    @Json(name = "is_day") val isDay: Int? = null,
    @Json(name = "precipitation") val precipitation: Float? = null,
    @Json(name = "weather_code") val weatherCode: Int? = null,
    @Json(name = "cloud_cover") val cloudCover: Int? = null,
    @Json(name = "pressure_msl") val pressureMsl: Float? = null,
    @Json(name = "wind_speed_10m") val windSpeed: Float? = null,
    @Json(name = "wind_direction_10m") val windDirection: Int? = null,
    @Json(name = "wind_gusts_10m") val windGusts: Float? = null,
    @Json(name = "uv_index") val uvIndex: Float? = null
)

@JsonClass(generateAdapter = true)
data class OpenMeteoHourly(
    @Json(name = "time") val time: List<String>? = null,
    @Json(name = "temperature_2m") val temperature: List<Float>? = null,
    @Json(name = "relative_humidity_2m") val relativeHumidity: List<Int>? = null,
    @Json(name = "precipitation_probability") val precipitationProbability: List<Int>? = null,
    @Json(name = "precipitation") val precipitation: List<Float>? = null,
    @Json(name = "weather_code") val weatherCode: List<Int>? = null,
    @Json(name = "wind_speed_10m") val windSpeed: List<Float>? = null,
    @Json(name = "wind_direction_10m") val windDirection: List<Int>? = null,
    @Json(name = "uv_index") val uvIndex: List<Float>? = null,
    @Json(name = "is_day") val isDay: List<Int>? = null
)

@JsonClass(generateAdapter = true)
data class OpenMeteoDaily(
    @Json(name = "time") val time: List<String>? = null,
    @Json(name = "weather_code") val weatherCode: List<Int>? = null,
    @Json(name = "temperature_2m_max") val temperatureMax: List<Float>? = null,
    @Json(name = "temperature_2m_min") val temperatureMin: List<Float>? = null,
    @Json(name = "apparent_temperature_max") val apparentTemperatureMax: List<Float>? = null,
    @Json(name = "apparent_temperature_min") val apparentTemperatureMin: List<Float>? = null,
    @Json(name = "sunrise") val sunrise: List<String>? = null,
    @Json(name = "sunset") val sunset: List<String>? = null,
    @Json(name = "uv_index_max") val uvIndexMax: List<Float>? = null,
    @Json(name = "precipitation_sum") val precipitationSum: List<Float>? = null,
    @Json(name = "precipitation_probability_max") val precipitationProbabilityMax: List<Int>? = null,
    @Json(name = "wind_speed_10m_max") val windSpeedMax: List<Float>? = null
)

@JsonClass(generateAdapter = true)
data class OpenMeteoGeocodingResponse(
    @Json(name = "results") val results: List<OpenMeteoGeoResult>? = null
)

@JsonClass(generateAdapter = true)
data class OpenMeteoGeoResult(
    @Json(name = "id") val id: Long? = null,
    @Json(name = "name") val name: String,
    @Json(name = "latitude") val latitude: Double,
    @Json(name = "longitude") val longitude: Double,
    @Json(name = "country") val country: String? = null,
    @Json(name = "country_code") val countryCode: String? = null,
    @Json(name = "admin1") val admin1: String? = null,
    @Json(name = "timezone") val timezone: String? = null
)
