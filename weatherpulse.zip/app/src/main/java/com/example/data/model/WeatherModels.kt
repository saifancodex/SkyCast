package com.example.data.model

data class CityLocation(
    val id: String = "",
    val name: String,
    val country: String,
    val countryCode: String? = null,
    val admin1: String? = null,
    val latitude: Double,
    val longitude: Double,
    val timezone: String,
    val isFavorite: Boolean = false
) {
    val displayName: String
        get() = if (!admin1.isNullOrBlank() && admin1 != name) "$name, $admin1" else "$name, $country"
}

enum class TemperatureUnit {
    CELSIUS,
    FAHRENHEIT;

    fun convertTemp(celsius: Float): Float {
        return when (this) {
            CELSIUS -> celsius
            FAHRENHEIT -> (celsius * 9f / 5f) + 32f
        }
    }

    val symbol: String
        get() = when (this) {
            CELSIUS -> "°C"
            FAHRENHEIT -> "°F"
        }

    val speedUnit: String
        get() = when (this) {
            CELSIUS -> "km/h"
            FAHRENHEIT -> "mph"
        }

    fun convertSpeed(kmh: Float): Float {
        return when (this) {
            CELSIUS -> kmh
            FAHRENHEIT -> kmh * 0.621371f
        }
    }

    val precipitationUnit: String
        get() = when (this) {
            CELSIUS -> "mm"
            FAHRENHEIT -> "in"
        }

    fun convertPrecipitation(mm: Float): Float {
        return when (this) {
            CELSIUS -> mm
            FAHRENHEIT -> mm * 0.0393701f
        }
    }
}

enum class GraphMetricType(
    val label: String,
    val metricUnit: String,
    val imperialUnit: String
) {
    TEMPERATURE("Temp", "°C", "°F"),
    RAIN_CHANCE("Rain", "%", "%"),
    WIND("Wind", "km/h", "mph"),
    HUMIDITY("Humidity", "%", "%"),
    UV_INDEX("UV Index", "UV", "UV")
}

data class HourlyDataPoint(
    val timeIso: String,
    val displayHour: String,
    val hourOfDay: Int,
    val temperatureC: Float,
    val precipitationProbability: Int,
    val precipitationMm: Float,
    val humidityPercent: Int,
    val windSpeedKmh: Float,
    val windDirectionDeg: Int,
    val uvIndex: Float,
    val weatherCode: Int,
    val condition: WeatherCondition,
    val isDay: Boolean
)

data class DailyForecastDay(
    val dateIso: String,
    val dayOfWeek: String,
    val shortDate: String,
    val weatherCode: Int,
    val condition: WeatherCondition,
    val tempMaxC: Float,
    val tempMinC: Float,
    val precipitationProbabilityMax: Int,
    val precipitationSumMm: Float,
    val uvIndexMax: Float,
    val windSpeedMaxKmh: Float,
    val sunriseTime: String,
    val sunsetTime: String,
    val hourlyPoints: List<HourlyDataPoint>
)

data class CurrentWeatherData(
    val location: CityLocation,
    val temperatureC: Float,
    val apparentTemperatureC: Float,
    val weatherCode: Int,
    val condition: WeatherCondition,
    val humidityPercent: Int,
    val precipitationProbability: Int,
    val precipitationMm: Float,
    val windSpeedKmh: Float,
    val windDirectionDeg: Int,
    val windGustsKmh: Float,
    val uvIndex: Float,
    val pressureHpa: Float,
    val cloudCoverPercent: Int,
    val isDay: Boolean,
    val tempMinC: Float,
    val tempMaxC: Float,
    val formattedDate: String,
    val formattedTime: String,
    val timezoneOffsetHours: Int,
    val sunriseTime: String,
    val sunsetTime: String,
    val hourlyForecast: List<HourlyDataPoint>,
    val fiveDayForecast: List<DailyForecastDay>,
    val lastUpdated: Long = System.currentTimeMillis()
) {
    val uvLevelDescription: String
        get() = when {
            uvIndex < 3f -> "Low"
            uvIndex < 6f -> "Moderate"
            uvIndex < 8f -> "High"
            uvIndex < 11f -> "Very High"
            else -> "Extreme"
        }

    val uvSunAdvice: String
        get() = when {
            uvIndex < 3f -> "Minimal sun protection needed. Safe for outdoor walks."
            uvIndex < 6f -> "Wear SPF 30+ sunglasses, seek midday shade."
            uvIndex < 8f -> "High sunburn risk. Hat, sunglasses, sunscreen essential."
            uvIndex < 11f -> "Very high risk. Avoid midday direct sun; wear protective clothing."
            else -> "Extreme alert! Avoid going outside during peak sun hours."
        }

    val rainSummary: String
        get() = when {
            precipitationProbability >= 70 -> "High chance of rain ($precipitationProbability%). Carry an umbrella!"
            precipitationProbability >= 40 -> "Showers possible ($precipitationProbability%). Keep rain gear ready."
            precipitationProbability >= 15 -> "Slight chance of rain ($precipitationProbability%). Mostly dry."
            else -> "Clear skies expected, negligible chance of rain."
        }

    val humidityComfort: String
        get() = when {
            humidityPercent < 30 -> "Dry air"
            humidityPercent in 30..60 -> "Comfortable"
            humidityPercent in 61..75 -> "Humid"
            else -> "Muggy / Very Humid"
        }

    val windDirectionCompass: String
        get() {
            val directions = arrayOf("N", "NNE", "NE", "ENE", "E", "ESE", "SE", "SSE",
                "S", "SSW", "SW", "WSW", "W", "WNW", "NW", "NNW")
            val index = (((windDirectionDeg % 360) + 360) % 360 / 22.5 + 0.5).toInt() % 16
            return directions[index]
        }
}
