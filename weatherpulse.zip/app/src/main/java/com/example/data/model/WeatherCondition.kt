package com.example.data.model

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Air
import androidx.compose.material.icons.filled.Cloud
import androidx.compose.material.icons.filled.Grain
import androidx.compose.material.icons.filled.NightsStay
import androidx.compose.material.icons.filled.Thunderstorm
import androidx.compose.material.icons.filled.WaterDrop
import androidx.compose.material.icons.filled.WbCloudy
import androidx.compose.material.icons.filled.WbSunny
import androidx.compose.material.icons.outlined.AcUnit
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector

enum class WeatherCondition(
    val code: Int,
    val description: String,
    val iconDay: ImageVector,
    val iconNight: ImageVector,
    val gradientTop: Color,
    val gradientBottom: Color,
    val accentColor: Color
) {
    CLEAR_SKY(
        code = 0,
        description = "Clear Sky",
        iconDay = Icons.Filled.WbSunny,
        iconNight = Icons.Filled.NightsStay,
        gradientTop = Color(0xFF0F3668),
        gradientBottom = Color(0xFF1E6091),
        accentColor = Color(0xFFFFB703)
    ),
    MAINLY_CLEAR(
        code = 1,
        description = "Mainly Clear",
        iconDay = Icons.Filled.WbSunny,
        iconNight = Icons.Filled.NightsStay,
        gradientTop = Color(0xFF184E77),
        gradientBottom = Color(0xFF1E6091),
        accentColor = Color(0xFFFFC300)
    ),
    PARTLY_CLOUDY(
        code = 2,
        description = "Partly Cloudy",
        iconDay = Icons.Filled.WbCloudy,
        iconNight = Icons.Filled.WbCloudy,
        gradientTop = Color(0xFF1A3A5B),
        gradientBottom = Color(0xFF335C67),
        accentColor = Color(0xFF90E0EF)
    ),
    OVERCAST(
        code = 3,
        description = "Overcast",
        iconDay = Icons.Filled.Cloud,
        iconNight = Icons.Filled.Cloud,
        gradientTop = Color(0xFF2B3A4A),
        gradientBottom = Color(0xFF4A5568),
        accentColor = Color(0xFFCBD5E1)
    ),
    FOG(
        code = 45,
        description = "Foggy",
        iconDay = Icons.Filled.Cloud,
        iconNight = Icons.Filled.Cloud,
        gradientTop = Color(0xFF334155),
        gradientBottom = Color(0xFF64748B),
        accentColor = Color(0xFFE2E8F0)
    ),
    DRIZZLE(
        code = 51,
        description = "Drizzle",
        iconDay = Icons.Filled.Grain,
        iconNight = Icons.Filled.Grain,
        gradientTop = Color(0xFF1E293B),
        gradientBottom = Color(0xFF3B82F6),
        accentColor = Color(0xFF60A5FA)
    ),
    RAIN(
        code = 61,
        description = "Rain",
        iconDay = Icons.Filled.WaterDrop,
        iconNight = Icons.Filled.WaterDrop,
        gradientTop = Color(0xFF0F172A),
        gradientBottom = Color(0xFF1E40AF),
        accentColor = Color(0xFF38BDF8)
    ),
    HEAVY_RAIN(
        code = 65,
        description = "Heavy Rain",
        iconDay = Icons.Filled.WaterDrop,
        iconNight = Icons.Filled.WaterDrop,
        gradientTop = Color(0xFF090D16),
        gradientBottom = Color(0xFF1E3A8A),
        accentColor = Color(0xFF0284C7)
    ),
    SNOW(
        code = 71,
        description = "Snow",
        iconDay = Icons.Outlined.AcUnit,
        iconNight = Icons.Outlined.AcUnit,
        gradientTop = Color(0xFF1E293B),
        gradientBottom = Color(0xFF475569),
        accentColor = Color(0xFFE0F2FE)
    ),
    THUNDERSTORM(
        code = 95,
        description = "Thunderstorm",
        iconDay = Icons.Filled.Thunderstorm,
        iconNight = Icons.Filled.Thunderstorm,
        gradientTop = Color(0xFF0F172A),
        gradientBottom = Color(0xFF312E81),
        accentColor = Color(0xFFFBBF24)
    ),
    WINDY(
        code = 999,
        description = "Breezy",
        iconDay = Icons.Filled.Air,
        iconNight = Icons.Filled.Air,
        gradientTop = Color(0xFF1E293B),
        gradientBottom = Color(0xFF2563EB),
        accentColor = Color(0xFF93C5FD)
    );

    companion object {
        fun fromWmoCode(code: Int): WeatherCondition {
            return when (code) {
                0 -> CLEAR_SKY
                1 -> MAINLY_CLEAR
                2 -> PARTLY_CLOUDY
                3 -> OVERCAST
                45, 48 -> FOG
                51, 53, 55, 56, 57 -> DRIZZLE
                61, 63, 80, 81 -> RAIN
                65, 66, 67, 82 -> HEAVY_RAIN
                71, 73, 75, 77, 85, 86 -> SNOW
                95, 96, 99 -> THUNDERSTORM
                else -> if (code in 50..69) RAIN else PARTLY_CLOUDY
            }
        }
    }
}
