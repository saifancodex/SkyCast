package com.example

import com.example.data.CityDatabase
import com.example.data.model.CityLocation
import com.example.data.model.GraphMetricType
import com.example.data.model.TemperatureUnit
import com.example.data.model.WeatherCondition
import com.example.data.repository.WeatherRepository
import com.example.util.DateTimeHelper
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

class WeatherLogicTest {

    @Test
    fun testTemperatureConversion() {
        val celsius = 25f
        val fahrenheit = TemperatureUnit.FAHRENHEIT.convertTemp(celsius)
        assertEquals(77f, fahrenheit, 0.01f)

        val freezingC = 0f
        assertEquals(32f, TemperatureUnit.FAHRENHEIT.convertTemp(freezingC), 0.01f)
    }

    @Test
    fun testSpeedConversion() {
        val kmh = 100f
        val mph = TemperatureUnit.FAHRENHEIT.convertSpeed(kmh)
        assertEquals(62.1371f, mph, 0.1f)
    }

    @Test
    fun testWeatherConditionMapping() {
        assertEquals(WeatherCondition.CLEAR_SKY, WeatherCondition.fromWmoCode(0))
        assertEquals(WeatherCondition.PARTLY_CLOUDY, WeatherCondition.fromWmoCode(2))
        assertEquals(WeatherCondition.OVERCAST, WeatherCondition.fromWmoCode(3))
        assertEquals(WeatherCondition.RAIN, WeatherCondition.fromWmoCode(61))
        assertEquals(WeatherCondition.HEAVY_RAIN, WeatherCondition.fromWmoCode(65))
        assertEquals(WeatherCondition.SNOW, WeatherCondition.fromWmoCode(71))
        assertEquals(WeatherCondition.THUNDERSTORM, WeatherCondition.fromWmoCode(95))
    }

    @Test
    fun testDateTimeHelperZonedTime() {
        val tokyoInfo = DateTimeHelper.getPlaceZonedInfo("Asia/Tokyo")
        assertNotNull(tokyoInfo.formattedTime)
        assertNotNull(tokyoInfo.formattedDate)
        assertTrue(tokyoInfo.timezoneDisplayName.contains("GMT+9"))

        val nyInfo = DateTimeHelper.getPlaceZonedInfo("America/New_York")
        assertNotNull(nyInfo.formattedTime)
        assertNotNull(nyInfo.formattedDate)
    }

    @Test
    fun testFallbackWeatherGeneration() {
        val repository = WeatherRepository()
        val tokyo = CityDatabase.POPULAR_CITIES.first { it.name == "Tokyo" }
        val weather = repository.generateFallbackWeather(tokyo)

        assertEquals("Tokyo", weather.location.name)
        assertTrue(weather.hourlyForecast.isNotEmpty())
        assertEquals(5, weather.fiveDayForecast.size)
        assertTrue(weather.temperatureC > -50f && weather.temperatureC < 60f)
    }
}
